// ignore_for_file: non_constant_identifier_names

// import 'package:hexcolor/hexcolor.dart';
//
// HexColor ButtonColor=HexColor("#080606");
// HexColor BackgroundColor=HexColor("#080606");
