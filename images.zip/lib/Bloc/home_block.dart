// @dart=2.12

import 'package:flutter_bloc/flutter_bloc.dart';
import 'home_state.dart';

class HomeCubit extends Cubit<CaseState> {
  HomeCubit() : super(CaseInitialState());

  static HomeCubit get(context) => BlocProvider.of(context);

}




