abstract class CaseState {}

class CaseInitialState extends CaseState {}
class ChangeResultState extends CaseState {}
class ChangeControllerState extends CaseState {}
class CleanState extends CaseState {}
