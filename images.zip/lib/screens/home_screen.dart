// @dart=2.12

// ignore_for_file: non_constant_identifier_names

import 'package:coffe_machien/Bloc/home_block.dart';
import 'package:coffe_machien/Bloc/home_state.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:hexcolor/hexcolor.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<HomeCubit, CaseState>(
      listener: (context, state) {},
      builder: (context, state) {
        var cubit = HomeCubit.get(context);
        var height = MediaQuery.of(context).size.height;
        var width = MediaQuery.of(context).size.width;

        return Scaffold(
          appBar: AppBar(
            backgroundColor: HexColor('#141414'),
            title: const Text(
              'Coffee Machine',
              style: TextStyle(color: Colors.white),
            ),
            actions: [
              IconButton(
                  onPressed: () {},
                  icon: const Icon(
                    Icons.settings,
                    color: Colors.white,
                  ))
            ],
          ),
          backgroundColor: HexColor('#141414'),
          body: SingleChildScrollView(
            child: SafeArea(
              child: Center(
                child: Padding(
                  padding: EdgeInsets.symmetric(horizontal: width / 44,vertical: height/44),
                  child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            Expanded(
                                child: MyCardWidget(context, 'Black Coffee')),
                            SizedBox(
                              width: width / 44,
                            ),
                            Expanded(
                                child: MyCardWidget(context, 'Black Coffee')),
                          ],
                        ),
                        SizedBox(
                          height: height / 44,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            Expanded(
                                child: MyCardWidget(context, 'Black Coffee')),
                            SizedBox(
                              width: width / 44,
                            ),
                            Expanded(
                                child: MyCardWidget(context, 'Black Coffee')),
                          ],
                        ),
                        SizedBox(
                          height: height / 44,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            Expanded(
                                child: MyCardWidget(context, 'Black Coffee')),
                            SizedBox(
                              width: width / 44,
                            ),
                            Expanded(
                                child: MyCardWidget(context, 'Black Coffee')),
                          ],
                        ),


                      ]),
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget MyCardWidget(context, txt) {
    return SizedBox(
      height: MediaQuery.of(context).size.height / 4,
      width: MediaQuery.of(context).size.width / 2,
      child: Card(
        color: Colors.black,
        elevation: 10.0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(25.0),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            SizedBox(height: MediaQuery.of(context).size.height / 60),
            const Expanded(
                flex: 3,
                child: Image(
                  image: AssetImage('images/coffe.png'),
                )),
            SizedBox(height: MediaQuery.of(context).size.height / 60),
            Expanded(
              child: Text(
                txt,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: MediaQuery.of(context).size.width / 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            SizedBox(height: MediaQuery.of(context).size.height / 50),
          ],
        ),
      ),
    );
  }
}
